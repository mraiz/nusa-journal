import{U as t,g as e,V as o}from"./DkDt2Mdh.js";const i=t((a,r)=>{if(e().isAuthenticated)return o("/companies")});export{i as default};
