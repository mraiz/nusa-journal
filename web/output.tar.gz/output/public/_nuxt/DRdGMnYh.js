import{U as a,g as e,V as o}from"./DkDt2Mdh.js";const h=a((t,u)=>{if(!e().isAuthenticated&&t.path!=="/auth/login")return o("/auth/login")});export{h as default};
